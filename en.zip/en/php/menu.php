<?php

$caller = basename($_SERVER["PHP_SELF"]);

if(\Portal\Sales::$Sale != \Portal\SaleType::None)
{
    echo '
        <li>
            <a class="text-3 text-danger text-color-hover-light dropdown-item appear-animation" data-appear-animation="rubberBand" data-appear-animation-delay="200" href="buy.phtml">' .\Portal\Sales::getSaleName() .'</a>
        </li>
    ';
}

    echo '         
        <li>
            <a class="text-3 font-weight-semibold text-color-white dropdown-item" href="index.phtml">HOME</a>
        </li>
        <li>
            <a class="text-3 font-weight-semibold text-color-white dropdown-item" href="features.phtml">FEATURES</a>
        </li>  
        <li>
            <a class="text-3 font-weight-semibold text-color-white dropdown-item" href="gallery.phtml">GALLERY</a>
        </li>  
        <li class="dropdown">
            <a class="text-3 font-weight-semibold text-color-white dropdown-item dropdown-toggle" href="#">LEARNING</a>
            <ul class="dropdown-menu">
                <li>
                    <a class="text-1 font-weight-semibold text-color-white dropdown-item" href="https://bitethebytes.freshdesk.com/support/solutions/folders/44001240071" target="_blank">TUTORIALS</a>
                </li>
                <li>
                    <a class="text-1 font-weight-semibold text-color-white dropdown-item" href="https://bitethebytes.freshdesk.com/support/solutions/44000815875" target="_blank">DOCUMENTATION</a>
                </li>
                <li>
                    <a class="text-1 font-weight-semibold text-color-white dropdown-item" href="https://bitethebytes.freshdesk.com/en/support/solutions/44000596986" target="_blank">FAQ</a>
                </li>
            </ul>   
        </li>  
        <li class="dropdown">
            <a class="text-3 font-weight-semibold text-color-white dropdown-item dropdown-toggle" href="#">SOCIALS</a>
            <ul class="dropdown-menu">
                <li>
                    <a class="text-1 font-weight-semibold text-color-white dropdown-item" href="https://discord.gg/worldcreator" target="_blank">DISCORD</a>
                </li>
                <li>
                    <a class="text-1 font-weight-semibold text-color-white dropdown-item" href="https://www.instagram.com/worldcreator3d/" target="_blank">INSTAGRAM</a>
                </li>
                <li>
                    <a class="text-1 font-weight-semibold text-color-white dropdown-item" href="https://www.youtube.com/channel/UClabqa6PHVjXzR2Y7s1MP0Q/" target="_blank">YOUTUBE</a>
                </li>
                <li>
                    <a class="text-1 font-weight-semibold text-color-white dropdown-item" href="https://vimeo.com/user82114310/" target="_blank">VIMEO</a>
                </li>
                <li>
                    <a class="text-1 font-weight-semibold text-color-white dropdown-item" href="https://www.twitch.tv/worldcreator3d/" target="_blank">TWITCH</a>
                </li>
                <li>
                    <a class="text-1 font-weight-semibold text-color-white dropdown-item" href="https://www.facebook.com/worldcreator3d/" target="_blank">FACEBOOK</a>
                </li>                
                <li>
                    <a class="text-1 font-weight-semibold text-color-white dropdown-item" href="https://www.artstation.com/worldcreator" target="_blank">ARTSTATION</a>
                </li>
            </ul>   
        </li>
        <li>
            <a class="text-3 font-weight-semibold text-color-white dropdown-item" href="buy.phtml">BUY</a>
        </li>
        <li>
            <a class="text-4 font-weight-semibold text-color-white dropdown-item" href="news.phtml"><i class="fa-solid fa-newspaper" data-bs-toggle="tooltip" data-bs-animation="false" data-bs-placement="bottom" title="News"></i></a>
        </li>
     ';

if(isset($_SESSION['worldcreator_manager_email']) && isset($_SESSION['worldcreator_manager_password']))
{
    echo '  
          <li class="dropdown">
                <a class="text-4 font-weight-semibold text-color-white dropdown-item dropdown-toggle ' . (str_starts_with($caller, "account_manager") ? 'active' : '') . '" href="#"><i class="fas fa-user-check" data-bs-toggle="tooltip" data-bs-animation="false" data-bs-placement="bottom" title="ACCOUNT"></i></a>
                <ul class="dropdown-menu">
                    <li>
                        <a class="dropdown-item" href="account_manager_dashboard.phtml">Dashboard</a>
                    </li>
                    <li>
                        <a class="dropdown-item" href="account_manager_seats.phtml">Seats</a>
                    </li>
                    <li class="dropdown-submenu">
                        <a class="dropdown-item" href="#">World Creator</a>
                        <ul class="dropdown-menu">
                            <li>
                                <a class="dropdown-item" href="account_manager_download_worldcreator_latest.phtml">Latest</a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="account_manager_download_worldcreator_legacy.phtml">Legacy</a>
                            </li>
                        </ul>                              
                    </li>
                    <li class="dropdown-submenu">
                        <a class="dropdown-item" href="#">Bridge Tools</a>
                        <ul class="dropdown-menu">
                            <li>
                                <a class="dropdown-item" href="account_manager_download_bridge_unity.phtml">Unity Engine</a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="account_manager_download_bridge_unreal.phtml">Unreal Engine</a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="account_manager_download_bridge_blender.phtml">Blender</a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="account_manager_download_bridge_cinema4d.phtml">Cinema4D</a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="account_manager_download_bridge_houdini.phtml">Houdini</a>
                            </li>
                        </ul>                              
                    </li>
                    <li class="dropdown-submenu">
                        <a class="dropdown-item" href="#">Assets</a>
                        <ul class="dropdown-menu">
                            <li>
                                <a class="dropdown-item" href="account_manager_download_content_materials.phtml">Materials</a>
                            </li>
                        </ul>                              
                    </li>';
    echo '<li>
                        <a class="dropdown-item" href="https://bitethebytes.freshdesk.com/support/tickets/new" target="_blank">Support Request</a>
                    </li>                    
                    <li>
                        <a class="dropdown-item" href="account_manager_featurerequest.phtml">Feature Request</a>
                    </li>
                    <li>
                        <a class="dropdown-item" href="account_manager_bugreport.phtml">Bug Report</a>
                    </li>
                    <li>
                        <a class="dropdown-item text-color-secondary" href="logout.phtml"><i class="fas fa-sign-out-alt pr-1"></i>LOG OUT</a>
                    </li>
                </ul>
             </li>
         ';
} else if(isset($_SESSION['worldcreator_user_email']) && isset($_SESSION['worldcreator_user_password']))
{
    echo '  <li class="dropdown">
                <a class="text-4 font-weight-semibold text-color-white dropdown-item dropdown-toggle ' . (str_starts_with($caller, "account_manager") ? 'active' : '') . '" href="#"><i class="fas fa-user-check" data-bs-toggle="tooltip" data-bs-animation="false" data-bs-placement="bottom" title="ACCOUNT"></i></a>
                <ul class="dropdown-menu">
                    <li>
                        <a class="dropdown-item" href="account_user_dashboard.phtml">Dashboard</a>
                    </li>
                    <li>
                        <a class="dropdown-item" href="account_user_seat.phtml">Seats</a>
                    </li>
                    <li class="dropdown-submenu">
                        <a class="dropdown-item" href="#">World Creator</a>
                        <ul class="dropdown-menu">
                            <li>
                                <a class="dropdown-item" href="account_user_download_worldcreator_latest.phtml">Latest</a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="account_user_download_worldcreator_legacy.phtml">Legacy</a>
                            </li>
                        </ul>                              
                    </li>
                    <li class="dropdown-submenu">
                        <a class="dropdown-item" href="#">Bridge Tools</a>
                        <ul class="dropdown-menu">
                            <li>
                                <a class="dropdown-item" href="account_user_download_bridge_unity.phtml">Unity Engine</a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="account_user_download_bridge_unreal.phtml">Unreal Engine</a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="account_user_download_bridge_blender.phtml">Blender</a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="account_user_download_bridge_cinema4d.phtml">Cinema4D</a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="account_user_download_bridge_houdini.phtml">Houdini</a>
                            </li>
                        </ul>                              
                    </li>
                    <li class="dropdown-submenu">
                        <a class="dropdown-item" href="#">Assets</a>
                        <ul class="dropdown-menu">
                            <li>
                                <a class="dropdown-item" href="account_user_download_content_materials.phtml">Materials</a>
                            </li>
                        </ul>                              
                    </li>
                    <li>
                        <a class="dropdown-item" href="https://bitethebytes.freshdesk.com/support/tickets/new" target="_blank">Support Request</a>
                    </li>                    
                    <li>
                        <a class="dropdown-item" href="account_user_featurerequest.phtml">Feature Request</a>
                    </li>
                    <li>
                        <a class="dropdown-item" href="account_user_bugreport.phtml">Bug Report</a>
                    </li>
                    <li>
                        <a class="dropdown-item text-color-secondary" href="logout.phtml"><i class="fas fa-sign-out-alt pr-1"></i>LOG OUT</a>
                    </li>
                </ul>
             </li>
         ';
} else
{
    echo '    
        <li>
            <a class="text-4 font-weight-semibold text-color-white dropdown-item ' . ($caller == "login.phtml" ? 'active' : '') . '" href="login.phtml"><i class="fas fa-user" data-bs-toggle="tooltip" data-bs-animation="false" data-bs-placement="bottom" title="Login"></i></a>
        </li>  
     ';
}

echo '
        <li class="dropdown">
            <a class="text-4 font-weight-semibold text-color-white dropdown-item dropdown-toggle" href="#"><i class="fas text-4 fa-globe-americas"></i></a>
            <ul class="dropdown-menu">
                <li>
                    <a class="text-1 font-weight-semibold text-color-white dropdown-item" href="https://www.world-creator.de/en/' . $caller . '" target="_self">ENGLISH</a>
                </li>
                <li>
                    <a class="text-1 font-weight-semibold text-color-white dropdown-item" href="https://www.world-creator.de/de/' . $caller . '" target="_self">DEUTSCH</a>
                </li>
            </ul>   
        </li>  
';

/*
echo '
        <li class="dropdown">
            <a class="dropdown-item dropdown-toggle text-3 font-weight-semibold text-color-white" href="#" role="button" id="dropdownLanguage" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas text-4 fa-globe"></i>
            </a>
            <div class="dropdown-menu" aria-labelledby="dropdownLanguage">
                <a class="dropdown-item text-color-grey text-1 background-transparent text-hover-light" href="https://www.world-creator.de/en/' . $caller . '">
                    <img src="../img/blank.gif" class="flag flag-us" alt="English" /> English</a>
                <a class="dropdown-item text-color-grey text-1 background-transparent text-hover-light" href="https://www.world-creator.de/de/' . $caller . '">
                    <img src="../img/blank.gif" class="flag flag-de" alt="Deutsch" /> Deutsch</a>
                <a class="dropdown-item text-color-grey text-1 background-transparent text-hover-light" href="https://www.world-creator.de/zh/' . $caller . '">
                    <img src="../img/blank.gif" class="flag flag-cn" alt="中國人" /> 中國人</a>
                <a class="dropdown-item text-color-grey text-1 background-transparent text-hover-light" href="https://www.world-creator.de/es/' . $caller . '">
                    <img src="../img/blank.gif" class="flag flag-es" alt="Español" /> Español</a>
                <a class="dropdown-item text-color-grey text-1 background-transparent text-hover-light" href="https://www.world-creator.de/fr/' . $caller . '">
                    <img src="../img/blank.gif" class="flag flag-fr" alt="Française" /> Française</a>
                <a class="dropdown-item text-color-grey text-1 background-transparent text-hover-light" href="https://www.world-creator.de/it/' . $caller . '">
                    <img src="../img/blank.gif" class="flag flag-it" alt="Italiano" /> Italiano</a>
                <a class="dropdown-item text-color-grey text-1 background-transparent text-hover-light" href="https://www.world-creator.de/jp/' . $caller . '">
                    <img src="../img/blank.gif" class="flag flag-jp" alt="日本" /> 日本</a>
                <a class="dropdown-item text-color-grey text-1 background-transparent text-hover-light" href="https://www.world-creator.de/kr/' . $caller . '">
                    <img src="../img/blank.gif" class="flag flag-kr" alt="한국인" /> 한국인</a>
                    <a class="dropdown-item text-color-grey text-1 background-transparent text-hover-light" href="https://www.world-creator.de/zh-tw/' . $caller . '">
                    <img src="../img/blank.gif" class="flag flag-tw" alt="中文 (繁體)" /> 中文 (繁體)</a>
                <a class="dropdown-item text-color-grey text-1 background-transparent text-hover-light" href="https://www.world-creator.de/ar/' . $caller . '">
                    <img src="../img/blank.gif" class="flag flag-sa" alt="العربية‏" /> العربية‏</a>
            </div>
        </li>';*/