<?php

session_start();

include_once '../../../php/portal/portal.php';

\Portal\Maintenance::handleUserPortal();

try
{
    if(!(isset($_POST['email']) && isset($_POST['password'])  && isset($_POST['submit']))) throw new \Exceptions\AccessDeniedException();

    $email = $_POST['email'];

    \Logger\Logger::write_login_website("LOGIN ATTEMPT: " . $email);

    // Check if email is valid (possible attack)
    if (!filter_var($email, FILTER_VALIDATE_EMAIL))
    {
        \Logger\Logger::write_login_website("LOGIN POSSIBLE ATTACK: " . $email);
        throw new \Exceptions\InvalidDataException("Invalid email format.");
    }

    $database = new Users\Database();

    // Check if email exists in database (possible attack)
    if (!$database->existsUserByEmail($email))
    {
        \Logger\Logger::write_login_website("LOGIN POSSIBLE ATTACK: " . $email);
        throw new \Exceptions\LoginFailedException();
    }

    $password = \Portal\Utility::encrypt($_POST['password']);

    $account = $database->selectAccountByEmailAndPassword($email, $password);
    if($account)
    {
        if($account->disabled) throw new \Exceptions\LoginDisabledException();

        if(isset($_POST['rememberme']))
        {
            setcookie("worldcreator_email", \Portal\Utility::encrypt($email), time() + 60 * 60 * 24 * 365);
            setcookie("worldcreator_password", $password, time() + 60 * 60 * 24 * 365);
        }

        $_SESSION["worldcreator_manager_email"] = $email;
        $_SESSION["worldcreator_manager_password"] = $password;
        $_SESSION['last_visit'] = time();

        \Logger\Logger::write_login_website("LOGIN SUCCESS (MANAGER): " . $email);

        header("Location: " . \Portal\Globals::$PATH_HOME . "account_manager_dashboard.phtml");
        return;
    }

    $account = $database->selectUserByEmailAndPassword($email, $password);

    if($account)
    {
        if($account->isDisabled) throw new \Exceptions\LoginDisabledException();

        if(isset($_POST['rememberme']))
        {
            setcookie("worldcreator_email", \Portal\Utility::encrypt($email), time() + 60 * 60 * 24 * 365);
            setcookie("worldcreator_password", $password, time() + 60 * 60 * 24 * 365);
        }

        $_SESSION["worldcreator_user_email"] = $email;
        $_SESSION["worldcreator_user_password"] = $password;
        $_SESSION['last_visit'] = time();

        \Logger\Logger::write_login_website("LOGIN SUCCESS (USER): " . $email);

        header("Location: " . \Portal\Globals::$PATH_HOME . "account_user_dashboard.phtml");
        return;
    }

    \Logger\Logger::write_login_website("LOGIN FAILED: " . $email);

    throw new \Exceptions\LoginFailedException();
}
catch(\Exceptions\InvalidDataException $ex)
{
    session_destroy();
    \Logger\Logger::write($ex->getMessage());
    header("Location: " . \Portal\Globals::getPathLogin() .'?err=' .$ex->getMessage());
    return;
}
catch(\Exceptions\AccessDeniedException $ex)
{
    session_destroy();
    \Logger\Logger::write($ex->getMessage());
    header("Location: " . \Portal\Globals::getPathLogin() .'?err=' .$ex->getMessage());
    return;
}
catch(\Exceptions\SessionUnavailableException $ex)
{
    session_destroy();
    \Logger\Logger::write($ex->getMessage());
    header("Location: " . \Portal\Globals::getPathLogin() .'?err=' .$ex->getMessage());
    return;
}
catch(\Exceptions\SessionExpiredException $ex)
{
    session_destroy();
    \Logger\Logger::write($ex->getMessage());
    header("Location: " . \Portal\Globals::getPathLogin() .'?err=' .$ex->getMessage());
    return;
}
catch(\Exceptions\LoginFailedException $ex)
{
    session_destroy();
    \Logger\Logger::write($ex->getMessage());
    header("Location: " . \Portal\Globals::getPathLogin() .'?err=' .$ex->getMessage());
    return;
}
catch(\Exceptions\LoginDisabledException $ex)
{
    session_destroy();
    \Logger\Logger::write($ex->getMessage());
    header("Location: " . \Portal\Globals::getPathLogin() .'?err=' .$ex->getMessage());
    return;
}
catch(\Exceptions\SqlException $ex)
{
    session_destroy();
    \Logger\Logger::write($ex->getMessage());
    header("Location: " . \Portal\Globals::getPathError());
    return;
}
catch(\Exception $ex)
{
    session_destroy();
    \Logger\Logger::write($ex->getMessage());
    header("Location: " . \Portal\Globals::getPathError());
    return;
}






