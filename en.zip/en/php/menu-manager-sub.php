<?php

$caller = basename($_SERVER["PHP_SELF"]);

if(isset($_SESSION['worldcreator_manager_email']) && isset($_SESSION['worldcreator_manager_password']) && isset($_SESSION['last_visit']))
{
echo '
    <section class="section section-default mt-0 mb-0 border-0 bg-color-dark-scale-6">
        <div class="row text-center">
            <div class="col">
                <a class="text-color-light" href="account_manager_dashboard.phtml"><button class="btn btn-sm btn-rounded ' . (str_starts_with($caller, "account_manager_dashboard.phtml") ? 'btn-primary' : 'btn-light') . ' btn-modern text-3 mt-1">Dashboard</button></a>
                <a class="text-color-light" href="account_manager_seats.phtml"><button class="btn btn-sm btn-rounded ' . (str_starts_with($caller, "account_manager_seats.phtml") ? 'btn-primary' : 'btn-light') . ' btn-modern text-3 mt-1">Seats</button></a>
                <div class="btn-group">
                    <button class="btn btn-sm btn-rounded ' . (str_starts_with($caller, "account_manager_download_worldcreator") ? 'btn-primary' : 'btn-light') . ' btn-modern text-3 dropdown-toggle mt-1" type="button" id="dropDownWorldCreator" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      World Creator
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropDownWorldCreator">
                      <a class="dropdown-item ' . (str_starts_with($caller, "account_manager_download_worldcreator_latest.phtml") ? 'active' : '') . '" href="account_manager_download_worldcreator_latest.phtml">LATEST</a>                      
                      <a class="dropdown-item ' . (str_starts_with($caller, "account_manager_download_worldcreator_legacy.phtml") ? 'active' : '') . '" href="account_manager_download_worldcreator_legacy.phtml">LEGACY</a>
                    </div>
                </div>
                <div class="btn-group">
                    <button class="btn btn-sm btn-rounded ' . (str_starts_with($caller, "account_manager_download_bridge") ? 'btn-primary' : 'btn-light') . ' btn-modern text-3 dropdown-toggle mt-1" type="button" id="dropDownBridge" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      Bridge Tools
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropDownBridge">
                      <a class="dropdown-item ' . (str_starts_with($caller, "account_manager_download_bridge_unity.phtml") ? 'active' : '') . '" href="account_manager_download_bridge_unity.phtml">UNITY BRIDGE</a>
                      <a class="dropdown-item ' . (str_starts_with($caller, "account_manager_download_bridge_unreal.phtml") ? 'active' : '') . '" href="account_manager_download_bridge_unreal.phtml">UNREAL BRIDGE</a>
                      <a class="dropdown-item ' . (str_starts_with($caller, "account_manager_download_bridge_blender.phtml") ? 'active' : '') . '" href="account_manager_download_bridge_blender.phtml">BLENDER BRIDGE</a>
                      <a class="dropdown-item ' . (str_starts_with($caller, "account_manager_download_bridge_cinema4d.phtml") ? 'active' : '') . '" href="account_manager_download_bridge_cinema4d.phtml">CINEMA 4D BRIDGE</a>
                      <a class="dropdown-item ' . (str_starts_with($caller, "account_manager_download_bridge_houdini.phtml") ? 'active' : '') . '" href="account_manager_download_bridge_houdini.phtml">HOUDINI BRIDGE</a>
                    </div>
                </div>
                <div class="btn-group">
                    <button class="btn btn-sm btn-rounded ' . (str_starts_with($caller, "account_manager_download_content") ? 'btn-primary' : 'btn-light') . ' btn-modern text-3 dropdown-toggle mt-1" type="button" id="dropDownBridge" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      Assets
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropDownBridge">
                      <a class="dropdown-item ' . (str_starts_with($caller, "account_manager_download_content_materials.phtml") ? 'active' : '') . '" href="account_manager_download_content_materials.phtml">MATERIALS</a>
                    </div>
                </div>                
                <a class="text-color-light" href="https://bitethebytes.freshdesk.com/support/tickets/new" target="_blank"><button class="btn btn-sm btn-light btn-rounded btn-modern text-3 mt-1">Support Request</button></a>
                <a class="text-color-light" href="account_manager_featurerequest.phtml"><button class="btn btn-sm ' . (str_starts_with($caller, "account_manager_featurerequest.phtml") ? 'btn-primary' : 'btn-light') . ' btn-modern btn-rounded text-3 mt-1">Feature request</button></a>
                <a class="text-color-light" href="account_manager_bugreport.phtml"><button class="btn btn-sm ' . (str_starts_with($caller, "account_manager_bugreport.phtml") ? 'btn-primary' : 'btn-light') . ' btn-modern btn-rounded text-3 mt-1">Bug Report</button></a>                
                <a class="text-color-danger" href="logout.phtml"><button class="btn btn-sm btn-light btn-modern btn-rounded text-3 mt-1 text-color-danger">Log Out</button></a>
            </div>
        </div>
    </section>
';
}
// <a class="text-color-light" href="account_manager_invoice.phtml"><button class="btn btn-sm ' . (str_starts_with($caller, "account_manager_invoice.phtml") ? 'btn-primary' : 'btn-light') . ' btn-modern text-2 mt-1">Invoice</button></a>
